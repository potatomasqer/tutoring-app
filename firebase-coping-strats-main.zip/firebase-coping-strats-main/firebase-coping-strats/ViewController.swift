//
//  ViewController.swift
//  firebase-coping-strats
//
//  Created by Andrew Deleanu on 9/22/22.
//

//apple
import UIKit
import CoreLocation
import CoreLocationUI

//firebase
import FirebaseCore
import FirebaseFirestore
import FirebaseAuth
import FirebaseDatabase
import FirebaseAppCheck

class ViewController: UIViewController, UITextFieldDelegate, CLLocationManagerDelegate, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var CurrentTime: UITextView!
    @IBOutlet weak var NameField: UITextField!
    @IBOutlet weak var AuthButton: UIButton!
    @IBOutlet weak var TableView: UITableView!
    @IBOutlet weak var StudentIDField: UITextField!
    
    let defults = UserDefaults.standard
    var startTime = "Time signed in today"
    var startDate:String = ""
    var CurentDate:String = ""
    var State = "Signed out"
    let locationManager = CLLocationManager()
    var localData: [String] = []

    func updateTime(){
        let userCalendar = Calendar.current
        let currentDateTime = Date()
        let requestedComponents: Set<Calendar.Component> = [
            .year,
            .month,
            .day,
            .hour,
            .minute,
            .second
        ]
        let dateTimeComponents = userCalendar.dateComponents(requestedComponents, from: currentDateTime)
        var time = ""
        if dateTimeComponents.minute! >= 10{
         time = String(dateTimeComponents.hour!) + ":" + String(dateTimeComponents.minute!)
        }
        else{time = String(dateTimeComponents.hour!) + ":0" + String(dateTimeComponents.minute!)}
        
        CurrentTime.text = time
        CurentDate = String(dateTimeComponents.month!) + "/" + String(dateTimeComponents.day!) + ", " + time
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //firebase stuff starts here i guess, FUCK YOU AARON
        //IS THIS JUST A GAME TO YOU
        
       let ref = Database.database().reference()
       ref.childByAutoId().setValue(["name":"Hello", "studentid":"Hi"])
        
        
        NameField.text = defults.string(forKey: "Name")
        StudentIDField.text = defults.string(forKey: "StudentID")
        let SBName = defults.string(forKey: "signIn")
        if SBName == "Sign out"{
            AuthButton.setTitle(SBName, for: .normal)
        }
        
        if defults.string(forKey: "Statekey") == "Signed in"{
            State = defults.string(forKey: "Statekey") ?? State
        }
        
        updateTime()
        
        AuthButton.updateConfiguration()
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
        
        //firebase set up
        //let firebase = FirebaseApp.app()
        //firebase.configure()
        //var ref: DatabaseReference!

        //ref = Database.database().reference()
        
    }
    
    @IBAction func SignIn(_ sender: UIButton) {
        updateTime()
        let name = NameField.text!
        defults.set(name, forKey: "Name")
        let id = StudentIDField.text!
        defults.set(id, forKey: "StudentID")
        
        StudentIDField.resignFirstResponder()
        NameField.resignFirstResponder()
        
        //location stuff
        if State == "Signed out"{
            //sign in
            let location = locationManager.location
            //print((String(location!.coordinate.latitude) + ", " + String(location!.coordinate.longitude)) )
            State = "Signed in"
            AuthButton.setTitle("Sign out", for: .normal)
            
            localData.append(String(State + ", " + CurentDate + "; " + name + ", " + id))
            
            TableView.reloadData()
            print(localData)

            defults.set(State, forKey: "Statekey")
            defults.set("Sign out", forKey: "signIn")
            
            NameField.text = ""
            StudentIDField.text = ""

            
            
        }else if State == "Signed in" { //state = signed in
            State = "Signed out"
            AuthButton.setTitle("Sign in", for: .normal)
            
            localData.append(String(State + ", " + CurentDate + "; " + name + ", " + id))
            
            TableView.reloadData()
            print(localData)
            
            defults.set(State, forKey: "Statekey")
            defults.set("Sign in", forKey: "signIn")

        }
        //print(State)

        }
        
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
         print("error:: \(error.localizedDescription)")
    }

    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            locationManager.requestLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {

        if locations.first != nil {
            //print("location:: (location)")
            _ = 1+1 //here so it dont print anything anoying
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        cell.textLabel!.text = localData[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return localData.count
    }
}

